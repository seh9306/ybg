<?php
require_once('C:\Program Files\Apache Software Foundation\Apache2.2\db.php');

function display_header($title,$n){

?>	
	<!doctype html>
	<html lang="ko">
	<head>
	<meta charset="UTF-8">
	<meta name="Generator" content="EditPlus®">
	<meta name="Author" content="">
	<meta name="Keywords" content="">
	<meta name="Description" content="">
	<script src="jquery-2.1.1.min.js"></script>
	<script>
	/*
		screen.width  screen.height => device screen 

	*/
	
	</script>
	<style>
		.btn { position:relative; overflow:hidden; background:#f6f6f6; margin:10px; padding:10px; border: 10px; border-radius:10px; box-shadow: 0 1px 3px rgba(0,0,0,.15); cursor:pointer; font-style:normal;}
		.btn:hover { background:#e9e9e9; }


		body { margin: 0px; padding: 0px; border: 0px; }
		body div#header { position:relative; background:#e9e9e9; box-shadow: 0 1px 3px rgba(0,0,0,.15); overflow:hidden; z-index:-1; }
		body div#header > * { margin:0px; font-size:12px; }
		body div#body { z-index:-1; }
		body div#body p.btn { font-size:20px; }
		<?php if($n==1){ ?>
		body div#box div.box { padding:15px; width:400px; display:none; background: #d9d9d9; border-radius:10px; overflow:hidden; }
		body div#box div.box span.btn { margin:20px; border:20px; position:relative; height:20px; font-size:15px; }
		body div#box div.box form#input 
		<?php
		if($_POST[style_boolean]==1)
		echo "{ display:visible; }";
		else 
		echo "{ display:none;}";
		?>
		body div#box div.box form#input input { margin:20px; padding:10px; }
		body div#box div.box form#input select { margin:10px; padding:10px; font-size:15px; }
		body div#box div.box form#input input.btn { margin:0px; } 
		body div#box div.box form#search { display:none; }
		<?php } ?>

	</style>
	<title><?php echo $title; ?></title>
<?php
}

function display_menu(){
	$query = "select * from main_page order by order_num";
	$result = dbconn($query); // require_once('db.php');

	for($i=0; $i<$result->num_rows; $i++){
		$row = $result->fetch_assoc();
		if($i==0) echo '<script> $(function(){';
		 ?>	
			$('<p class="btn"><?php echo $row[page_content]; ?></p>').click(function(){ location.assign("<?php echo $row[url_info]; ?>"); }).appendTo('body div#body')
		<?php if ($i==$result->num_rows-1) echo '}); </script> ';
	}
				// $('body').html('<p></p>'); delete contents of oldbody and insert contents
				// assign turn your page on present page make history
				// replace " don't make history;
}

function display_select($table){
	$query = "select * from ".$table." order by order_num";
	$result = dbconn($query); // require_once('db.php');
	for($i=0; $i<$result->num_rows; $i++){
		$row = $result->fetch_assoc();
		if($i==0) echo '<script> $(function(){  ';
	?>	
	var tag ='<p class="btn"><?php echo $row[page_content]; ?></p>'
	$(tag).appendTo('body div#body')
	<?php //if ($i==$result->num_rows-1) echo '}); </script> ';
	}
	$result->close();

 	?>
	var tag ='body div#box div.box div#btn';
	for(var i=0;i< 60;i++){

		$('<span>'+Number(i+1)+' </span>').appendTo(tag);
	}

	// insert mySQL
	<?php if($_POST[style_boolean]==1){ ?>
	$('body div#body p.btn').toggle().eq(<?php echo $_POST[order_num];?>).show();
	$('body div#box div.box').toggle().find('form#input input[name=order_num]').val(<?php echo $_POST[order_num];?>);
	<?php 
	$query = "select page_content from ".$table." where order_num ='".($_POST[order_num]+1)."'";
	$result = dbconn($query);
	$row = $result->fetch_assoc();
	$query = "update success set ".str_replace(' ','',$row['page_content'])."='".$_POST['success']."' where 조 = '".$_POST['group_num']."'";
	$result = dbconn($query);
	} ?>

	$('body div#body p.btn').click(function(){ 
		var order_num = $(this).index();
			$('body div#body p.btn').toggle().eq(order_num).show();
			$('body div#box div.box').toggle().find('form#input input[name=order_num]').val(order_num);
	});

	
	// part of input
	$('body div#box div.box span.btn.input').click(function() {
		$('body div#box div.box form#search').hide('fast').siblings('form#input').toggle('fast');

	});

	$('body div#box div.box div#input p.btn').click(function() {
	<?php
	// 입력식 인풋 박스에 값을 구해 그 값을 조로 사용하고, 합격으로 넣어준다.
	// 페이지는 나눠져 있고, $(this).index() 몇번째 값(mysql상에서 order_num을 의미)
	// 에 있는 과제인지를 구하고 해당과제의 해당 인풋박스 값을 조로 해서 합격 시킨다.
		$query = "update success set 사격='y' where 조 =''";
		$result = dbconn($query); // require_once('db.php');
	?>	
		
	});

	// part of button
	$('body div#box div.box span.btn.search').click(function() {
		$('body div#box div.box form#input').hide('fast');
		$('body div#box div.box form#search').toggle('fast');
	});

	$('body div#box div.box ').click(function() {
		var i = $(this).index();
	});



});
	</script>
<?php
}

function moving_script() {

?>
	<script>
		$(function(){
			
			//var r = 'body div#body p';
			//$(r).hover(
			//	function(){ $(this).css('background', '#e9e9e9')},
			//	function(){ $(this).css('background', '#f6f6f6')} 
			//); 
			// hover event can realize css3 style but cann't realize animation.



			//$('body').keydown(function(){
			//	<?php 
			//		$query = "select admin from admin";
			//		$result = dbconn($query); // require_once('db.php');
			//		$row = $result->fetch_assoc();
			//	?>
			//	switch(event.keyCode){
			//		case 65:	
			//			<?php
			//				if ($row[admin]=='a')
			//				{
			//					$query = "update admin set admin='b' where admin='a'";
			//					$result = dbconn($query);
			//				}
			//			?>
			//	}
			//});
			// ..
		});
	</script>
<?php
}

function display_body($n) {
	// try{  throw new Exception("Error Message",1); How to use Exception
?> 
	</head>
	<body>

		<div id='header'>
			<button class='btn'>뒤로가기</button>
			<p align='center'><img src='main.png'></p>
		</div>
		<div id='body' align='center'>
		</div>
		<?php if($n==1){ ?>
		<div id='box' align='center'>
			<div class='box' value='2'>
				<span class='btn input'>입력</span>
				<form id='search' align='center' method='post' action=''>
					<input name='search' type='submit' class='btn' value='조회'>
				</form>
				<span class='btn search'>조회</span>
				<form id='input' align='center' method='post' action=''>
					<input name='group_num' type='text' size=30%><br>
					<input name='style_boolean' type='hidden' value='1'>
					<input name='order_num' type='hidden' value=''>
					<select name="success">
						 <option value="y">합격
						 <option value="n">불합격
						 <option value="w">대기중
					</select>
					<input type='submit' class='btn' size=50% value='입 력'>
				</form>
			</div>
		</div>
		<?php } ?>
	</body>
</html>
<?php

	//	} catch(exception $e) { 
	//echo "Exception ". $e->getCode(). ": ". $e->getMessage()."<br />". " in ". $e->getFile(). " on line ". $e->getLine(). "<br />"; 
	//}
}
?>