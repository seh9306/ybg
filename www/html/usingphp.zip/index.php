<?php
	require_once('display_all.php');
	display_main_header('평가시스템');
	display_select_body();
	display_main_footer();
?>
